import {Router} from 'express';
import {AlimentosController} from '../controllers/alimentosController';

class alimentosRoutes{
    public router: Router = Router();
    constructor(){
        this.config();
    }

    config():void{
        this.router.get('/alimentos',AlimentosController.getProducts);
        this.router.get('/alimentos:id',AlimentosController.getProductById);
        this.router.post('/alimentos',AlimentosController.createProduct);
        this.router.delete('/alimentos:id',AlimentosController.deleteProduct);
        this.router.put('/alimentos:id',AlimentosController.updateProduct);
    }
}

const AlimentosRoutes =new alimentosRoutes();
export default AlimentosRoutes.router;