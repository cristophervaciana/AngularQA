import pg from 'pg-promise';

const cn = 'postgres://postgres:Wa789rtiy569@localhost:5432/alacena';

const db = pg();

const connection = db(cn)

connection.connect().then(cnn =>{
    console.log('Se conecto');

}).catch(err=>{
    console.log('error de conexion'+err);
});

export default connection;


