import {Request,Response} from 'express';

class indexController{
    public index(req:Request,res:Response){
        res.send('Hello');
    }



}

export const IndexController = new indexController();