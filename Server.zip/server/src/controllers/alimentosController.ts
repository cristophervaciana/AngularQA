import {Request,Response} from 'express';
import db from '../database';
class alimentosController{
    public async getProducts(req:Request,res:Response): Promise<void>{
        await db.query('select * from alimento')
        .then(data => {
            res.json(data); // print new user id;
        })
        .catch(error => {
            res.json('no existen productos'+error); // print error;
        });       
    }
    public async getProductById(req:Request,res:Response): Promise<any>{
        const {id} = req.params;
        await db.one('select * from alimento where idAlimento = $1',Number(id.substring(1)))
        .then(data => {
                return res.json(data);
        })
        .catch(error => {
            return res.status(404).json({text:'el producto no existe '+error}); // print error;
        });  
    }
    public async createProduct(req:Request,res:Response): Promise<void>{
        //console.log(req.body);
        await db.query('insert into alimento (nombre,foto,cantidad,fechaCaducidad) VALUES(${nombre},${foto},${cantidad},${fechacaducidad})', req.body)
            .then(data => {
                res.json('Agrego'); // print new user id;
            })
            .catch(error => {
                res.json('no Agrego'); // print error;
            });
            
    }
    public async deleteProduct(req:Request,res:Response){
        const {id} = req.params;
        await db.query('delete from alimento where idalimento = $1',Number(id.substring(1)))
        .then(data => {
                res.json({text:"alimento eliminado"});
        })
        .catch(error => {
            res.json({text:'el producto no existe '+error}); // print error;
        }); 
    }
    public async updateProduct(req:Request,res:Response){
        const {id} = req.params;
        const {nombre,foto,cantidad,fechacaducidad} = req.body;
        await db.query('update alimento set nombre = $1,foto= $2,cantidad= $3,fechaCaducidad= $4 where idalimento = $5',[nombre,foto,cantidad,fechacaducidad,Number(id.substring(1))])
        .then(data => {
                res.json({text:"alimento editado"});
        })
        .catch(error => {
            res.json({text:'el producto no existe '+error}); // print error;
        }); 
    }
}

export const AlimentosController = new alimentosController();